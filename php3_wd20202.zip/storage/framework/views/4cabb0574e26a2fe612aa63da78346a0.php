<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Trang chủ</title>
</head>

<body>
    <h1>Trang chủ</h1>
    <div>
        <a href="<?php echo e(route('admin.users')); ?>">Admin User</a> |
        <a href="<?php echo e(route('admin.products')); ?>">Admin Products</a> |
        <a href="<?php echo e(route('products.comment', ['slug' => 'iphone', 'id' => 12])); ?>">Product Comment</a>
    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\php3_wd20202\resources\views/welcome.blade.php ENDPATH**/ ?>